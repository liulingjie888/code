package cn.ecut.util;

/**
 * @author lujiapeng
 * @className StatusCode
 * @description TODO
 * @date 2020/9/17 16:40
 **/
public final class StatusCode {
    public static final Integer SUCCESS = 0 ;
    public static final Integer SERVER_ERROR = -1 ;

}
