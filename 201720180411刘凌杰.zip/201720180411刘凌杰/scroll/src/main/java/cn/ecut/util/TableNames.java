package cn.ecut.util;

/**
 * @author lujiapeng
 * @className TableNames
 * @description TODO
 * @date 2020/9/17 14:39
 **/
public final class TableNames {
    public static final String USER_TABLE_NAME = " t_users " ;
    public static final String CONTENT_TABLE_NAME = " t_content " ;
    public static final String DISCUSS_TABLE_NAME = " t_discuss " ;
}
