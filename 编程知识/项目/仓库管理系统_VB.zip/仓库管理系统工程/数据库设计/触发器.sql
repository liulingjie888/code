 use storage
 
go
--�Զ����ӵ�����
create trigger product_insert
on product 
after insert
as	
	declare @id char(10)
	select @id=(select p_id from inserted)
	insert into profit
	values (@id,0,0,0)
	update product
	set p_date2=DATEADD(DD,p_day,p_date1)
	where p_id=@id


go
create trigger product_update
on product
after update
as
	declare @id char(10)
	select @id=(select p_id from inserted)
	if(update(p_cost) or update(p_cost))
	begin
		exec t_sto_pro @id
		
		update export
		set total_price=(select e_number from export where p_id=@id) * (select p_sold from product where p_id=@id)
		where p_id=@id

		update re_sales
		set total_price=(select r_number from re_sales where p_id=@id) * (select p_sold from product where p_id=@id)
		where p_id=@id
		
		update import
		set total_price=(select i_number from import where p_id=@id) * (select p_cost from product where p_id=@id)
		where p_id=@id
	end
	if (update(p_date1) or update(p_day))
	begin
		update product
		set p_date2=DATEADD(DD,p_day,p_date1)
		where p_id=@id
	end


--����ͬ���ֿ⣬����
go
create trigger import_insert_update
on import
after insert,update
as
	declare @id char(10),@date date
	select @id =(select p_id from inserted),
	@date =(select i_date from inserted)
	exec t_sto_pro @id
	update import
	set total_price=(select i_number from import where p_id=@id and i_date=@date) * (select p_cost from product where p_id=@id)
	where p_id=@id and i_date=@date

go
create trigger import_delete
on import
after delete
as
	declare @id char(10)
	select @id =(select p_id from inserted)
	exec t_sto_pro @id


--����ͬ���ֿ⣬����
go
create trigger export_insert_update
on export
after insert,update
as
	declare @id char(10),@date date
	select @id =(select p_id from inserted),
	@date=(select e_date from inserted)
	exec t_sto_pro @id
	update export
	set total_price=(select e_number from export where p_id=@id and e_date=@date) * (select p_sold from product where p_id=@id)
	where p_id=@id and e_date=@date


go
create trigger export_delete
on export
after delete
as
	declare @id char(10)
	select @id =(select p_id from inserted)
	exec t_sto_pro @id


--�˻�ͬ���ֿ⣬����
go
create trigger re_sales_insert_update
on re_sales
after insert,update
as
	declare @id char(10),@date date
	select @id =(select p_id from inserted),
	@date=(select r_date from inserted)
	exec t_sto_pro @id
	update re_sales
	set total_price=(select r_number from re_sales where p_id=@id and r_date=@date) * (select p_sold from product where p_id=@id)
	where p_id=@id and r_date=@date


go
create trigger re_sales_delete
on re_sales
after delete
as
	declare @id char(10)
	select @id =(select p_id from inserted)
	exec t_sto_pro @id

--����������
go
create trigger profit_insert_update
on profit
after insert,update
as
	declare @id char(10)
	select @id=(select p_id from inserted)
	update profit
	set p_profit =sold-cost
	where p_id=@id

--����ɾ��
go
create trigger product_delete
on product
instead of delete
as
	declare @id char(10)
	select @id=(select p_id from deleted)
	delete from import where p_id=@id
	delete from export where p_id=@id
	delete from re_sales where p_id=@id
	delete from profit where p_id=@id
	delete from product where p_id=@id

	