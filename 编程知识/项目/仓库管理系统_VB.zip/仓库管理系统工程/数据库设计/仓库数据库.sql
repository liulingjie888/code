create database STORAGE
on primary
(
	name=storage_data,
	filename='D:\storage_data.mdf',
	size=5MB,
	maxsize=50MB,
	filegrowth=1MB
)
log on
(
	name=storage_log,
	filename='D:\storage_log.ldf',
	size=1MB,
	maxsize=10MB,
	filegrowth=1%
)