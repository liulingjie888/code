package client;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;

public class Login implements ActionListener{
	private static final int frame_width=380;				//���ڿ���
	private static final int frame_height=250;
	private static final int frame_left=600;				//����λ��
	private static final int frame_top=250;
	protected Font font=new Font("Dialog",0,15);
	protected Font font1=new Font("Dialog",1,15);
	protected JFrame frame;
	protected JTextField text_user;
	protected JPasswordField text_passwd;
	protected JButton btn_send,btn_register;
	private static JLabel label1,label2;
	

	public Login(){
		createFrame();
		//���ӷ��Ϳ�ݷ�ʽ
		sendShortCut();
	}
	private void createFrame(){
		frame=new JFrame("�������");
		frame.setBounds(frame_left, frame_top, frame_width, frame_height);
//		frame.setFont(new Font("Dialog",0,15));
		frame.setLayout(null);
		frame.setResizable(false);
		
		label1=new JLabel("�û���");		//��ǩ
		label2=new JLabel("����");
		label1.setFont(font);
		label2.setFont(font);
		label1.setBounds(40,35,50,30);
		label2.setBounds(40,80,50,30);
		
		btn_send=new JButton("����");	//��ť
		btn_register= new JButton("ע��");
		btn_send.setFont(font1);
		btn_register.setFont(font1);
		btn_send.setSize(80,30);
		btn_register.setSize(80,30);
		btn_send.setLocation(110,140);
		btn_register.setLocation(230,140);
//		btn_register.addActionListener(this);
//		btn_send.addActionListener(this);
		
		text_user=new JTextField();		//�ı�
		text_passwd=new JPasswordField();
		text_user.setFont(font);
		text_passwd.setFont(font);
		text_user.setLocation(110, 35);
		text_passwd.setLocation(110,80);
		text_user.setSize(200,30);
		text_passwd.setSize(200,30);
		
		frame.add(label1);
		frame.add(label2);
		frame.add(text_user);
		frame.add(text_passwd);
		frame.add(btn_send);
		frame.add(btn_register);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void sendShortCut() {
		text_passwd.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==10) {
					btn_send.doClick();
				}
				
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO �Զ����ɵķ������
				
			}
			
		});
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==btn_send) {
			
		}else {
		
		}
	}
//	public static void main(String[] args) {
//		// TODO �Զ����ɵķ������
//		new Login();
//	}

}
