package client;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
public class Register extends JFrame{
	private static final int frame_width=380;				//���ڿ���
	private static final int frame_height=250;
	private static final int frame_left=600;				//����λ��
	private static final int frame_top=250;
	protected Font font=new Font("Dialog",0,15);
	protected Font font1=new Font("Dialog",1,15);
	JTextField text_user;
	JPasswordField text_passwd;
	protected  JButton btn_register, btn_back;
	private  JLabel label1,label2;
	
	public Register() {
		createFrame();	
		//���ӷ��Ϳ�ݷ�ʽ
		sendShortCut();
	}
	private void createFrame() {
		label1=new JLabel("�û���");		//��ǩ
		label2=new JLabel("����");
		label1.setFont(font);
		label2.setFont(font);
		label1.setBounds(40,35,50,30);
		label2.setBounds(40,80,50,30);
		
		btn_register=new JButton("ע��");	//��ť
		btn_back= new JButton("����");
		btn_register.setFont(font1);
		btn_back.setFont(font1);
		btn_register.setSize(80,30);
		btn_back.setSize(80,30);
		btn_register.setLocation(110,140);
		btn_back.setLocation(230,140);
	
		text_user=new JTextField();		//�ı�
		text_passwd=new JPasswordField();
		text_user.setFont(font);
		text_passwd.setFont(font);
		text_user.setLocation(110, 35);
		text_passwd.setLocation(110,80);
		text_user.setSize(200,30);
		text_passwd.setSize(200,30);
		setResizable(false);
		setTitle("ע�����");
		setBounds(frame_left, frame_top, frame_width, frame_height);
		setLayout(null);
		
		add(label1);
		add(label2);
		add(text_user);
		add(text_passwd);
		add(btn_back);
		add(btn_register);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void sendShortCut() {
		text_passwd.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==10) {
					btn_register.doClick();
				}
				
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO �Զ����ɵķ������
				
			}
		});
		
		
	}

}
