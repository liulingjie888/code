package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AddFriends extends JFrame {
	private static final int frame_width=380;				//���ڿ���
	private static final int frame_height=230;
	private static final int frame_left=600;				//����λ��
	private static final int frame_top=250;
	protected JTextField text_friends;
	protected JButton btn_find;
	private static JLabel label1;
	

	public AddFriends(){
		createFrame();
	}
	private void createFrame(){
		setTitle("��������");
		setBounds(frame_left, frame_top, frame_width, frame_height);
		setLayout(null);
		setResizable(false);
		
		label1=new JLabel("�����ǳ�");		//��ǩ
		label1.setBounds(40,35,100,30);
		
		btn_find=new JButton("���Ӻ���");	//��ť
		btn_find.setSize(110,30);
		btn_find.setLocation(170,100);
		
		text_friends=new JTextField();		//�ı�
		text_friends.setLocation(110, 35);
		text_friends.setSize(200,30);
		
		add(label1);
		add(text_friends);
		add(btn_find);
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
//	public static void main(String[] args) {
//		// TODO �Զ����ɵķ������
//		new AddFriends();
//	}

}
