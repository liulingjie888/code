package client;

import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;


public class Message extends JFrame{
	private static final int frame_width=300;				//���ڿ���
	private static final int frame_height=300;
	private static final int frame_left=600;				//����λ��
	private static final int frame_top=250;
	protected Font font=new Font("Dialog",0,15);
	protected JList<String> list;
	protected DefaultListModel<String> listmodel;
	protected JScrollPane scrollpane;


	public Message() {
		setTitle("��Ϣ֪ͨ");
		setBounds(frame_left, frame_top, frame_width, frame_height);
		setLayout(null);
		
		
		listmodel=new DefaultListModel<String>();
		list=new JList<String>(listmodel);
		list.setFont(font);
		scrollpane=new JScrollPane(list);
		scrollpane.setSize(280,250);
		add(scrollpane);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	
//	public static void main(String[] args) {
//		// TODO �Զ����ɵķ������
//		new Message().setVisible(true);
//	}

}
