use serverchat

insert into users
values (default,'111','232')

insert into users
values (0,'2222','232')

insert into usermessage
values (default,1,2,'111������Ϣ���',getdate(),default)
insert into usermessage
values (default,1,2,'111������Ϣ�Ұ���',getdate(),default)
insert into usermessage
values (default,1,2,'111������Ϣ����һЩ��������',getdate(),default)
insert into usermessage
values (default,1,2,'111����������',getdate(),default)

use SERVERCHAT


select * from requests
select * from users
select * from usermessage
select * from number
select * from userfriends where user_id=6

delete from requests
delete from userfriends where user_id=2 and friend_id=4
delete from userfriends where user_id=4 and friend_id=2
delete from usermessage where timedate is null
select * from users where user_name='3333'

insert into userfriends values(2,4,'34324')
insert into userfriends values(4,2,'111')
insert into userfriends values(2,3,'3333')
insert into userfriends values(3,2,'111')
insert into userfriends values(2,1,'2222')
insert into userfriends values(1,2,'111')
insert into userfriends values(2,6,'liulingjie')
insert into userfriends values(6,2,'111')

select * from usermessage where flag=0 AND user_id='1'

update usermessage set flag=1 where text_id='6'



insert into userfriends values(6,4,'34324')
insert into userfriends values(4,6,'liulingjie')
insert into userfriends values(6,3,'3333')
insert into userfriends values(3,6,'liulingjie')
insert into userfriends values(6,1,'2222')
insert into userfriends values(1,6,'liulingjie')

insert into usermessage values (default,2,1,'"+chat_frame.sendtext.getText()+"',getdate(),default)

update usermessage set flag=1 where text_id=8

update usermessage set flag=1 where text_id=30

delete from usermessage where timedate is NULL

insert into usermessage values(default,7,6,'7;;��',null,default)

insert into usermessage values(default,8,9,'9',null,default)