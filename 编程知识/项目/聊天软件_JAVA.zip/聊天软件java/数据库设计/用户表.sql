go
drop table users
create table users
(

user_id int primary key default 0,--�û�id
user_name varchar (20) unique not null,	--�û�����
user_password varchar(30) not null,	--�û�����

)
drop table userfriends
create table userfriends
(
user_id int foreign key references users(user_id), --�û�id
friend_id int foreign key references users(user_id),--����id
friend_name varchar(20),				--��������
 primary key(user_id,friend_id)			
)
drop table usermessage
create table usermessage
(
--start varchar(10),
text_id int default 0 primary key,
user_id int foreign key references users(user_id),	--�û�id
friend_id int foreign key references users(user_id),			--����id
message_text text not null,
timedate datetime,
flag bit default 0,
)
--��������֪ͨ
drop table requests
create table requests
(
user_id int foreign key references users(user_id),
friend_id int foreign key references users(user_id),
friend_name varchar(20) foreign key references users(user_name),
flag int default 0,
primary key(user_id,friend_id)

)

--��¼����
drop table number
create table number
(
num_id varchar(20) primary key,
num int default 0
)
--������Ϣ����
insert into number values('usermessage',0)
insert into number values('users',0)
---------------------------------------------------


--�Զ������������
go
create trigger after_insert_usermessage
on usermessage
after insert
as
	declare @number int
	select @number=(select num from number where num_id='usermessage' )		--��ȡ����
	update number set num=@number+1 where num_id='usermessage'
	update usermessage set text_id=@number+1 where text_id=0


------------------------------------------------------------------------------

--�Զ������û�id
go
create trigger after_insert_users
on users
after insert
as
	declare @number int
	select @number=(select num from number where num_id='users' )		--��ȡ����
	update number set num=@number+1 where num_id='users'
	update users set user_id=@number+1 where user_id=0

--------------------------------------------------------------------------
use SERVERCHAT
select * from usermessage where flag=0 AND user_id='111'

