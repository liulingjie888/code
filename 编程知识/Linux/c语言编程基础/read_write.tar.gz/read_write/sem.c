#include "rw.h"

void init(){
    sem_id1=semget(ftok(".",'a'), 1, 0666|IPC_CREAT);        //创建一个信号量
    printf("读1信号量创建成功,标识符为%d\n",sem_id1);
    init_sem(sem_id1,1);

    sem_id2=semget(ftok(".",'b'), 1, 0666|IPC_CREAT);        //创建一个信号量
    printf("读1信号量创建成功,标识符为%d\n",sem_id2);
    init_sem(sem_id2,1);
}

int init_sem(int sem_id,int init_value){
    union semun sem_union;
    sem_union.val=init_value;
    if(semctl(sem_id,0,SETVAL,sem_union)==-1){
        perror("Initialize semaphore");
        return -1;
    }
    return 0;
}

int del_sem(int sem_id){
    union semun sem_union;
    if(semctl(sem_id,0,IPC_RMID,sem_union)==-1){
        perror("Delete semaphore");
        return -1;
    }
}

/*p操作函数*/
int sem_p(int sem_id)
{
    struct sembuf sem_b;
    sem_b.sem_num=0;
    sem_b.sem_op=-1;
    sem_b.sem_flg=SEM_UNDO;
    if(semop(sem_id,&sem_b,1)==-1)
    {
        perror("P operation");
        return -1;
    }
    return 0;
}
/*v操作函数*/
int sem_v(int sem_id)
{
    struct sembuf sem_b;
    sem_b.sem_num=0;
    sem_b.sem_op=1;
    sem_b.sem_flg=SEM_UNDO;
    if(semop(sem_id,&sem_b,1)==-1)
    {
        perror("V operation");
        return -1;
    }
    return 0;
}