#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include<sys/sem.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include<sys/stat.h>
#include<fcntl.h>

 #define child 4    //进程数量

int sem_id1,sem_id2;         //信号量id

union  semun        //初始化信号量的额结构体
{
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};


void init();
int init_sem(int sem_id,int init_value);
int del_sem(int sem_id);
int sem_p(int sem_id);
int sem_v(int sem_id);

void write1();
void write2();
void read1();
void read2();

// int main()
// {
//     int share_file;
//     share_file=open(sharefile,O_RDWR,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);

// }
