#include "rw.h"

 char sharefile[]="sharefile.txt";   //共享文件
int main(int argc, char const *argv[])
{   
	pid_t pid;
 
	init();		//初始化信号量

    for (int i = 0; i < child; ++i){
    	if (pid=fork()==0){
    		// printf("子进程%d：%d\n",i+1,getpid());
 
			switch (i){
				case 0:
					sem_p(sem_id1);
					sem_p(sem_id2);
					write1();
					sem_v(sem_id1);
					sem_v(sem_id2);
					break;
				case 1:
					sem_p(sem_id1);
					read1();
					sem_v(sem_id1);
					break;
				case 2:
					sem_p(sem_id1);
					sem_p(sem_id2);
					write2();
					sem_v(sem_id1);
					sem_v(sem_id2);
					break;
				case 3:
					sem_p(sem_id2);
					read2();
					sem_v(sem_id2);
					break;
			
				default:
					break;
			}

    		return 0;//结束子进程
    	}

		

    	// waitpid(pid,NULL,WUNTRACED);//等待当前子进程结束
    }

    // printf("\n");
    // printf("父进程结束:%d\n",getpid());
 
	return 0;
}

void write1(){
	// int i;
	// for(i=0;i<10;i++){
	// 	printf("write1: %d\n",i);
	// }
	// printf("\n");
	char content[]="write1 success\0";
	int fd=open(sharefile,O_WRONLY|O_APPEND,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
	if(fd<0){
		printf("write1 open fail\n");
		exit(1);
	}
	write(fd,content,strlen(content));
	printf("write1已写入内容\n");
}

void write2(){
	// int i;
	// for(i=0;i<10;i++){
	// 	printf("write2: %d\n",i);
	// }
	// printf("\n");
	char content[]="write2 success\0";
	int fd=open(sharefile,O_WRONLY|O_APPEND,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
	if(fd<0){
		printf("write2 open fail\n");
		exit(1);
	}
	write(fd,content,strlen(content));
	printf("write2已写入内容\n");
}

void read1(){
	// int i;
	// for(i=0;i<10;i++){
	// 	printf("read1: %d\n",i);
	// }
	// printf("\n");
	int len=0;
	char content[1024];
	int fd=open(sharefile,O_RDONLY);
	if(fd<0){
		printf("read1 open fail\n");
		exit(1);
	}
	len=read(fd,content,1024);
	printf("read1读出内容: %s\n",content);

}

void read2(){
	// int i;
	// for(i=0;i<10;i++){
	// 	printf("read2: %d\n",i);
	// }
	// printf("\n");
	int len=0;
	char content[1024];
	int fd=open(sharefile,O_RDONLY);
	if(fd<0){
		printf("read1 open fail\n");
		exit(1);
	}
	len=read(fd,content,1024);
	printf("read2读出内容: %s\n",content);
}
